#Attention!
If you want new version of TelegramSiteHelper (each customet in new chatroom)
Please Twitter tweet: 
`@telegram #telegramPleaseMakeBotPossibleToCreateGroup`

#Внимание!
Друзья, если вы хотите новый более удобный чат (с разделением менеджеров по чатам)
Пожалуйста сделайте tweet в Твиттере:
`@telegram #telegramPleaseMakeBotPossibleToCreateGroup`


# Telegram-Site-Helper-2.0
Little chat (based on Telegram BOT platform) for creating web site helper

Installation info: https://habrahabr.ru/post/302056/ (in russian)

Если не можете установить сами - закажите установку: <a href="https://voltsoft.ru/telegram-site-helper">https://voltsoft.ru/telegram-site-helper</a>
<br>
<br>
Donate by <b>PayPal</b> to andrey.surzhikov@gmail.com<br>
Donate by <b>YandexMoney</b> 4100168691358<br>
Donate by <b>BTC</b> 1HKb4L5YTQjcH6HYYEk1dXsuUWWmNYRkDj<br>
Donate by <a href="https://money.yandex.ru/embed/donate.xml?account=4100168691358&quickpay=donate&payment-type-choice=on&mobile-payment-type-choice=on&default-sum=100&targets=%D0%9F%D0%BE%D0%B4%D0%B4%D0%B5%D1%80%D0%B6%D0%BA%D0%B0+%D0%BF%D1%80%D0%BE%D0%B5%D0%BA%D1%82%D0%B0&target-visibility=on&project-name=Telegram+Site+Helper+2%2F0&project-site=https%3A%2F%2Fgithub.com%2FSurzhikov%2FTelegram-Site-Helper-2.0&button-text=01&successURL=https%3A%2F%2Fraw.githubusercontent.com%2FSurzhikov%2FTelegram-Site-Helper-2.0%2Fmaster%2Fthank-you.txt"><b>Visa</b>/<b>Mastercard</b></a><br><br>

<img src="https://habrastorage.org/files/bfb/eb5/242/bfbeb52421b349dba8aa9d40b8729e81.png"/>

<img src="https://habrastorage.org/files/c9c/3ed/1f9/c9c3ed1f96a848b2aa3e043213f499d5.png"/>

<img src="https://habrastorage.org/files/a0d/073/459/a0d07345976f4613873dd94f1d4ac0fc.png"/>

<img src="https://habrastorage.org/files/3f5/e6c/d15/3f5e6cd1569a466db2300d292a5228c8.png"/>

<img src="https://habrastorage.org/files/6be/002/fe5/6be002fe52cc40d2a967683311fabfff.png"/>
